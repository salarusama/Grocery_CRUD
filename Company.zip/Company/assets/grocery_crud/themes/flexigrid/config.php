<?php 
$config['crud_paging'] = true;
