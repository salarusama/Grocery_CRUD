<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
<?php
if (isset($this->session->userdata['logged_in'])) {
$username = ($this->session->userdata['logged_in']['username']);
$email = ($this->session->userdata['logged_in']['email']);

} else {
header("location: http://localhost:1234/Company/index.php/user_authentication");
}
?>

<?php

foreach($css_files as $file): ?>
    <link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>


<style type='text/css'>
body
{
    font-family: Arial;
    font-size: 14px;
}
a {
    color: blue;
    text-decoration: none;
    font-size: 14px;
}
a:hover
{
    text-decoration: underline;
}
</style>

</head>
<body>
<!-- Beginning header -->

<div>
<h1 style="text-align: center; color: blue; font-family: Georgia; ">Be U World Wide Ltd Address Book</h1>
</div>
    
    <div style="text-align: center; color: blue; font-size: 32px ; font-family: Georgia">
        <a href='<?php echo site_url('user_authentication/addressess')?>'>Addressess</a> | 
        <a href='<?php echo site_url('user_authentication/Staff')?>'>Staff</a> |
        <a href='<?php echo site_url('user_authentication/Tanzania')?>'>Tanzania</a> |
         <a href='<?php echo site_url('user_authentication/Logout')?>'>Logout</a> 
        <!-- <a href='<?php echo site_url('examples/products_management')?>'>Products</a> | 
        <a href='<?php echo site_url('examples/film_management')?>'>Films</a>  --> 
 
    </div>
<!-- End of header-->
    <div style='height:20px;'></div>  
    <div>
<?php echo $output; ?>
 
    </div>
<!-- Beginning footer -->
<!-- <div>Footer</div> -->
<!-- End of Footer -->
</body>
</html>
 